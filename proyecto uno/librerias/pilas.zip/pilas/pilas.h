/********************************************************************|
|    esta libreria tiene como finalidad trabajar el TDA lista        |
|    para cualquier tipo de dato nativo o estructurado.              |
|********************************************************************/
#ifndef _PILAS_H
#define _PILAS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//*******************************|    TIPOS DE DATOS    |*********************************//


typedef enum{
    INT,
    FLOAT,
    CHAR,
    DOUBLE,
    STRING,
    STRUCT
} tipo_dato;

typedef struct{
    tipo_dato tipo;
    void* dato;
} item_pila;

typedef struct nodo{
    item_pila item;
    struct nodo *siguiente;
} nodo;

typedef struct pila{
    tipo_dato dato_arbitrario;
    nodo *cima;
    int total;
    void (*imprimir)(void*);
    size_t tam;
} pila;

//*******************************|    FUNCIONES DEL TIPO ITEM    |*********************************//

// se encarga de procesar un dato para ser un dato "generico"
item_pila _preparar(tipo_dato tipo, void *valor, size_t tam);

//libera el espacio en memoria del dato generico
void liberar_item(item_pila *entrada);

//muestra el item, si es una estructura, pasar el puntero a la funcion
//que la muestra, caso contrario poner NULL 
void mostrar_item(item_pila entrada, void (*imprimir)(void *));

//*******************************|    FUNCIONES DEL TIPO PILA    |*********************************//

// se encarga de crear una pila vacia
pila crear_pila(tipo_dato tipo, size_t tam ,void (*imprimir)(void*)); //check

// se encarga de agregar un dato a la pila
void apilar(pila *p, void *dato, tipo_dato tipo);

// se encarga de eliminar un dato de la pila
void *desapilar(pila *p);

// se encarga de eliminar todos los datos de la pila
void eliminar_pila(pila *p);

// se encarga de imprimir todos los datos de la pila
//no se debe usar sino en casos de prueba
void imprimir_pila(pila *p);

#endif
