#include "listas.h"

//*******************************|    FUNCIONES DEL TIPO ITEM    |*********************************//

item_lista preparar(tipo_dato tipo, void *valor, size_t tam){
    item_lista nuevo;
    nuevo.tipo = tipo;
    nuevo.dato = malloc(tam);
    if(nuevo.dato == NULL){
        perror("error al asignar memoria");
        exit(EXIT_FAILURE);
    }
    memcpy(nuevo.dato, valor, tam);
    return nuevo;
}

void liberar_item(item_lista *entrada){
    if(entrada->dato != NULL){
        free(entrada->dato);
        entrada->dato = NULL;
    }
}
//*******************************|    FUNCIONES DEL TIPO LISTA    |*********************************//

// funcion constructora encargada de definir una lista y el tipo que esta puede almacenar, en caso de ser una estructura definir tambien una funcion
// para poder imprimirla, caso contrario, poner NULL
lista crear_lista(tipo_dato tipo, void (*imprimir)(void*)){
    lista l;
    l.dato_arbitrario = tipo;
    l.imprimir = imprimir;
    l.total = 0;
    l.primero = NULL;
    return l;
}

// guarda un item a la lista, si el item no es permitido se detiene la operacion sin agregarse nada
void agregar(lista *l, void *item, tipo_dato tipo, size_t tam){
    if(l->dato_arbitrario != tipo){
        perror("tipo de dato no soportado\n");
        return;
    }else{
        //crear el item
        item_lista nuevo = preparar(l->dato_arbitrario, item, tam);

        //crear el nodo
        nodo *nuevo_nodo = (nodo *)malloc(sizeof(nodo));
        if(nuevo_nodo == NULL){
            perror("error al asignar memoria a nodo\n");
            exit(EXIT_FAILURE);
        }
        
        if(l->primero == NULL){
            nuevo_nodo->item = nuevo;
            nuevo_nodo->siguiente = l->primero;
            l->primero = nuevo_nodo;

        }else{
            nodo *aux = l->primero;
            while(aux->siguiente != NULL){
                aux = aux->siguiente;
            }
            
            aux->siguiente = nuevo_nodo;
            nuevo_nodo->item = nuevo;
            nuevo_nodo->siguiente = NULL;
            
        }
        
        l->total = l->total+1;

    }
}

//muestra los elementos de la lista
void mostrar_lista(lista l){
    nodo *aux = l.primero;
    switch (l.dato_arbitrario){
        case INT:
            while(aux != NULL){
                printf("%d ", *(int*)aux->item.dato);
                aux = aux->siguiente;
            }
        
        break;

        case FLOAT:
            while(aux != NULL){
                printf("%f ", *(float*)aux->item.dato);
                aux = aux->siguiente;
            }

        break;
        
        case CHAR:
            while(aux != NULL){
                printf("%c ", *(char*)aux->item.dato);
                aux = aux->siguiente;
            }
            
        break;
        
        case DOUBLE:
            while(aux != NULL){
                printf("%f ", *(double*)aux->item.dato);
                aux = aux->siguiente;
            }
            
        break;

        case STRING:
            while(aux != NULL){
                printf("%s ", (char*)aux->item.dato);
                aux = aux->siguiente;
            }
            
        break;

        case STRUCT:
            /*
                NOTA:   es importante que el programador defina una funcion para imprimir
                el tipo de estructura que va a utilizar y  poner la funcion al inicializar
                la lista.
                ejemplo:
                typedef struct carta{
                    int valor;
                    char palo;
                } carta;

                void mostrar_carta(void *dato){
                    carta *c = (carta*)dato;
                    printf("Valor: %d, Palo: %c\n", c->valor, c->palo);
                }
                lista l = crear_lista(STRUCT, &mostrar_carta);
            */
            
            while(aux != NULL){
                l.imprimir(aux->item.dato);
                //printf("%d ", *(int*)aux->item.dato);
                aux = aux->siguiente;
            }
            
        break;

        default:
        break;
    }
    printf("\n");

}

//quita un elemento de la lista
void quitar(lista *l, int posicion){
    if(l->primero == NULL){
        printf("La lista esta vacia\n");
        return;
    }
    
    if(posicion <= 0 || posicion > l->total){
        printf("La posicion no existe\n");
        return;
    }
    
    if(posicion == 1){
        nodo *aux = l->primero;
        l->primero = l->primero->siguiente;
        l->total = l->total -1;
        
        liberar_item(&(aux->item));
        free(aux);
        return;
    }else{
        nodo *aux = l->primero;
        int i = 1;
        while(aux->siguiente != NULL && i < posicion-1){
            aux = aux->siguiente;
            i++;
        }
        
        if(aux->siguiente == NULL){
            printf("La posicion no existe\n");
            return;
        }else{
            nodo *aux2 = aux->siguiente;
            aux->siguiente = aux->siguiente->siguiente;
            l->total = l->total -1;
            liberar_item(&(aux2->item));
            free(aux2);
            return;
        }
    }
}

//operacion destructora que elimina la lista por completo liberando el espacio reservado del item y el espacio reservado del nodo
void eliminar_lista(lista *l){
    while(l->primero != NULL){
        nodo *aux = l->primero;
        l->primero = l->primero->siguiente;
        liberar_item(&(aux->item));
        free(aux);
        l->total--;
    }
    l->imprimir = NULL;

    if(l->total != 0){
        printf("error al borrar la lista\n");

    }else{
        l->primero = NULL;
        printf("lista eliminada\n");
    }
    return;
}
