/********************************************************************|
|    esta libreria tiene como finalidad trabajar el TDA lista        |
|    para cualquier tipo de dato nativo o estructurado.              |
|********************************************************************/
#ifndef _LISTAS_H
#define _LISTAS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//*******************************|    TIPOS DE DATOS    |*********************************//


typedef enum{
    INT,
    FLOAT,
    CHAR,
    DOUBLE,
    STRING,
    STRUCT
} tipo_dato;

typedef  struct{
    tipo_dato tipo;
    void* dato;
} item_lista;

typedef struct nodo{
    item_lista item;
    struct nodo *siguiente;
}nodo;

typedef struct lista{
    int total;
    nodo *primero;
    tipo_dato dato_arbitrario;
    void (*imprimir)(void*); //puntero a funcion para poder imprimir estructuras definidas por algun usuario
} lista;

//*******************************|    FUNCIONES DEL TIPO ITEM    |*********************************//

item_lista preparar(tipo_dato tipo, void *valor, size_t tam);
void liberar_item(item_lista *entrada);

//*******************************|    FUNCIONES DEL TIPO LISTA    |*********************************//


/*
    funcion constructora encargada de definir una lista y el tipo que esta puede almacenar, en caso de ser una estructura
    definir tambien una funcion para poder imprimirla, caso contrario, poner NULL
*/
lista crear_lista(tipo_dato tipo, void (*imprimir)(void*));


// guarda un item a la lista, si el item no es permitido se detiene la operacion sin agregarse nada
// ejemplo con tipo entero:
//int i = 0; 
//agregar(&l,&i,INT, sizeof(int));

void agregar(lista *l, void *item, tipo_dato tipo, size_t tam);

//muestra los elementos de la lista
void mostrar_lista(lista l);

//quita un elemento de la lista
void quitar(lista *l, int posicion);

//operacion destructora que elimina la lista por completo liberando el espacio reservado del item y el espacio reservado del nodo
void eliminar_lista(lista *l);

#endif
